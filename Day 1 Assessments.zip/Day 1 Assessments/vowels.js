string='CITIUSTECH'
function getVowels(string) {
  var Vowels = "aAeEiIoOuU";
  var vowelsCount = 0;
  for (var i = 0; i < string.length; i++) {
    if (Vowels.indexOf(string[i]) !== -1) {
      vowelsCount += 1;
    }
  }
  console.log(`vowels found in character ${str} are ${vowelsCount}`);
}
function removeDuplicate(string)
{
   return string.split('')
    .filter(function(item, pos, self)
    {
      return self.indexOf(item) == pos;
    }
   ).join('');
}
 
var str = "CITIUSTECH";
string= " "+removeDuplicate(str);
getVowels(string);

// getVowels(string);

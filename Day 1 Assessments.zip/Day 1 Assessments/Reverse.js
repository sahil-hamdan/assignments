let rev = 0;
num = 550095
let lastDigit;

while (num != 0) {
    lastDigit = num % 10;
    rev = rev * 10 + lastDigit;
    num = Math.floor(num / 10);
}

//alert('Reverse Number : '+rev);
console.log("Reverse number : " + rev)


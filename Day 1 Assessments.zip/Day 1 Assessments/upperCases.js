str = ["Ronaldo", "Uthman", "khalid", "Abbas", "Umar"];
for (let i = 0; i < str.length; i++) {
    //removing last string of char using slice and adding last part of string with upperCase
    str[i]=str[i].slice(0,str[i].length-1)+ str[i].slice(str[i].length-1).toUpperCase();
}
console.log(str);
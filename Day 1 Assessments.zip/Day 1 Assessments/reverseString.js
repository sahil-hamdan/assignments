var word="Tim humble";
var revWords ="";
/* here in for loop, length of given word is stored in "i" and decremented by one 
// last index of character is added in new string variable i.e revWord
 and decremented again  and added to revWords till i is greater and equal to 0
*/
for (let i =word.length -1; i>= 0; i--){
     revWords += word[i];
}
     
    
console.log(`The reverse of the word ${word} is ` +revWords);
let num = [];
let i = 10; // Array size
console.log("Array elements are :");
for (let ele = 0; ele < i; ele++) {
  num[ele] = parseInt(window.prompt("Enter array Element " + (ele + 1)));
  console.log(num[ele]);
}
console.log("display even array elements :");
//let evenNum = [];
let res = 0;
for (let j = 0; j < 10; j++) {
  if (num[j] % 2 == 0) {
    res+= num[j];
  }
}

if(res === 0){
    console.log('No Even Numbers Found');
}
else{
    console.log(`Sum : ${res}`);
}
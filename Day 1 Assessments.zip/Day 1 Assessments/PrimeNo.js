//Prime no is the number that divisible by 1 and itself

const lowerNo = 3;
const higherNo = 50;

console.log(`The prime numbers between ${lowerNo} and ${higherNo} are:`);

//for loop for read number from lowerNumber to Highernumber and assigning flag=0
for (let i = lowerNo; i <= higherNo; i++) {
    let flag = 0;

    for (let j = 2; j < i; j++) {
        if (i % j == 0) {
            flag = 1;
            break;
        }
    }
/*by defination Prime should divisible by 1 and itself.
Here we are creating for loop to check if the given number divisible by other number,
Between the Range of 2 to 1- given number,
if this condition is true then it's not a prime number  */ 
    if (i > 1 && flag == 0) {
        console.log(i);
    }
/* here we are going display the prime number*/
}
//let num = new Array(0,10,20,30,40,50,60,70,80,90);
//or
let num= [10,50,80,30,100,20,70,15,40,60];
greatNum=Math.max(...num);
for(let i=0; i< num.length;i++){
    if(num[i]===greatNum){
        num.splice(i,1);
        i--;
    }
}
secondGreat=Math.max(...num);
console.log("the two greatest num of array are: "+greatNum +'\t'+secondGreat);

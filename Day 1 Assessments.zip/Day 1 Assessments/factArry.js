let num=[2,3,4,5,6];
fact_res=[];
for(let i=0;i<num.length;i++){
    fact=1;
    for(let j=num[i];j>0;j--){
        fact=fact*j;
    }
        fact_res.push(fact);
}
console.log(fact_res);
let num= [10,50,80,30,100,20,70,15,40,60];
console.log("the reverse order of array are: ");
for(let i=num.length-1; i>=0;i--){
        console.log(num[i])
    };

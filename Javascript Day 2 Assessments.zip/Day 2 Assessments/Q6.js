// 6.	Rewrite the function created in assignment 1 as an arrow function.
let fact=(n)=>{
    let f=1;
    for(let i=1;i<=n;i++)
    {
     f=f*i;
    }
    return console.log(`factorial of ${n} is ${f}`);
    
 }
 fact(0);
 fact(5);
 fact(4);
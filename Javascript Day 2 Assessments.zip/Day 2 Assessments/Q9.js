// 9.	Write a JS function which takes 3 arguments, namely arg1, arg2 and arg3. Call the function by passing an array of 3 elements to it. The function must return the maximum value from the array passed to it.
function max(arg1, arg2, arg3) {
  arg2 = arg1[1];
  arg3 = arg1[2];
  arg1 = arg1[0];
  console.log(`The max of ${arg1} , ${arg2} and ${arg3} is ${Math.max(arg1, arg2, arg3)}`);
}
const array = [1, 2, 3];
max(array);

// 8.	Write a JS function which returns the sum of any number of arguments passed. If no arguments are passed, the function must return a zero.
function sum(...a) {
  res = 0;
  for (i = 0; i < a.length; i++) {
    res += a[i];
  }
  console.log(`The Sum of ${a} = ${res}`);
}
sum(5,6,1);
sum(4,5,6,7,8,9);
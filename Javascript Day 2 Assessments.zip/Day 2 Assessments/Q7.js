// 7.	Pass the object created in assignment 5 to an arrow function. The function must return a string which contains the vehicleid, brand, ,model, variant & speed.
const vehicle = {
    id: 7872,
    brand: "BMW",
    model: "2022",
    variant: "Off Road",
    specifications: {
      firstGear: function () {
        console.log(
          "This message displaying to show that vehicle is in firstGear "
        );
      },
      secondGear: function () {
        console.log(
          "This message displaying to show that vehicle is in secondGear"
        );
      },
      maxSpeed: 220,
      changeGear: function () {
        return this.firstGear(), this.secondGear();
      },
    },
  };
  const fact =(vehicle)=>{

  }
    console.log(JSON.stringify(vehicle));
  
  fact();
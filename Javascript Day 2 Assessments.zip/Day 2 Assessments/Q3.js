//3.	Write a standard JS function which takes variable number of arguments and prints each argument on the screen and also the number of arguments passed.
function argu(...a){
    for(i=0;i<a.length;i++){
    console.log(a[i])
}
console.log(`Total number of agruments: ${a.length}`)
}
console.log(argu(2,"hello",10,"Goodbye"))
/* 
5.	Create a JS object which stores the following details about a vehicle:
vehicleid                a number
brand                      a string
model                     a string
variant                    a string
specifications             an object containing the following members:
                                    firstGear          a function which logs some message
                                    secondGear     a function which logs some message
                                    maxSpeed       a number
                                    changeGear    a function which calls “firstGear” and 
    “secondGear” functions 
Print the vehicleid, brand, model, variant on the browser console. Invoke the changeGear function & display the speed on the browser console.

*/
const vehicle = {
  id: 7872,
  brand: "BMW",
  model: "2022",
  variant: "Off Road",
  specifications: {
    firstGear: function () {
      console.log(
        "This message displaying to show that vehicle is in firstGear "
      );
    },
    secondGear: function () {
      console.log(
        "This message displaying to show that vehicle is in secondGear"
      );
    },
    maxSpeed: 220,
    changeGear: function () {
      return this.firstGear(), this.secondGear();
    },
  },
};
const fact = (vehicle) => {
  console.log(`vehicleid: ${vehicle.id} 
brand: ${vehicle.brand}
model : ${vehicle.model}
variant: ${vehicle.variant}`);
  vehicle.specifications.changeGear();
  console.log(
    `The Max Speed of vehicle is : ${vehicle.specifications.maxSpeed}`
  );
};
fact(vehicle);

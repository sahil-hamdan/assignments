// 4.	Write a JS arrow function named Login() which takes a username and password. In case any of the arguments or both are not passed, the default values must be CT and CT respectively. 
let login=( userName="CT" , passWord="CT")=> console.log(`Username:${userName} and Password is : ${passWord} `);
login("Khalid","Based@Khalid")
login("Khalid")
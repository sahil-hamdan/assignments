//1.	Write a standard JS function which takes a number as an argument and returns its factorial.
function fact(n) {
  let f=1;
    for(let i=1;i<=n;i++)
    {
     f=f*i;
    }
    return console.log(`factorial of ${n} is ${f}`);
}
fact(5);
fact(0);






//2.	Write a JS arrow function which takes 2 numbers and returns their sum.

let myFunction =(x, y) => x + y;
console.log(myFunction(5,10));